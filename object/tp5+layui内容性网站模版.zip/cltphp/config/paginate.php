<?php
/**
 * Created by PhpStorm.
 * User: ldc
 * Date: 2018/6/6
 * Time: 15:50
 */
return [
    'type'      => 'clt\Bootstrap',
    'var_page'  => 'page',
    'list_rows' => 8,
];