<?php
return [
    // 模板文件名分隔符
    'taglib_pre_load'    => 'app\common\taglib\Clt',
];