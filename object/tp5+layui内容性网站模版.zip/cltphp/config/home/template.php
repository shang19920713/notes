<?php
return [
    // 模板文件名分隔符
    'view_depr'    => '_',

];

