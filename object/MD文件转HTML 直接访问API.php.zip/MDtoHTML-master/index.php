<?php
	echo file_get_contents("https://markdown.win/api.php?url=https://markdown.win/README.md");
?>