<?php
namespace Home\Controller;
use Think\Controller;
include_once './Public/video/aliyun-php-sdk-core/Config.php';
use vod\Request\V20170321 as vod;
class IndexController extends Controller {
	public function index(){
		$this->display();
	}
    public function getvideo(){
		$regionId = 'cn-shanghai';
		$profile = \DefaultProfile::getProfile($regionId, "您的access_key_id", "您的access_key_secret");
		$client = new \DefaultAcsClient($profile);
		$request = new vod\CreateUploadVideoRequest();
		//视频源文件标题(必选)
		$request->setTitle($_POST['title']);
		//视频源文件名称，必须包含扩展名(必选)
		$request->setFileName($_POST['name']);
		//视频源文件字节数(可选)
		$request->setFileSize(0);
		//视频源文件描述(可选)
		$request->setDescription("视频描述");
		//自定义视频封面URL地址(可选)
		$request->setCoverURL("");
		//上传所在区域IP地址(可选)
		$request->setIP("127.0.0.1");
		//视频标签，多个用逗号分隔(可选)
		$request->setTags("");
		//视频分类ID(可选)
		$request->setCateId(0);
		$response = $client->getAcsResponse($request);
		$data['UploadAuth']=$response->UploadAuth;
		$data['UploadAddress']=$response->UploadAddress;
		$data['VideoId']=$response->VideoId;
		$data['RequestId']=$response->RequestId;
		$this->ajaxReturn($data);
	}
	
	
	public function hui(){
		$body = file_get_contents('php://input');
		$data=json_decode($body,true);
		$VideoId=$data['VideoId'];//视频id
		$status1=$data['StreamInfos'][0]['Status'];
		$status2=$data['StreamInfos'][1]['Status'];
		if($data['StreamInfos'][0]['Format']=="mp4"){
			$mp4=$data['StreamInfos'][0]['FileUrl'];//mp4格式播放地址
			$m3u8=$data['StreamInfos'][1]['FileUrl'];//m3u8格式播放地址
		}else{
			$mp4=$data['StreamInfos'][1]['FileUrl'];
			$m3u8=$data['StreamInfos'][0]['FileUrl'];
		}
		if(($status1=="success") && ($status2=="success")){
			$this->writelog(date("m-d-H-i-s"),"转码完成，视频id：".$VideoId."\r\n\r\n mp4格式播放地址：".$mp4."\r\n\r\n m3u8格式播放地址：".$m3u8);
		}else{
			$this->writelog(date("m-d-H-i-s"),"转码失败\r\n\r\n ErrorCode：".$data['StreamInfos'][0]['ErrorCode']." - ".$data['StreamInfos'][1]['ErrorCode']."\r\n\r\n ErrorMessage：".$data['StreamInfos'][0]['ErrorMessage']." - ".$data['StreamInfos'][1]['ErrorMessage']);
		}
	}
	
	public function writelog($filename,$content){
		$date = date('Y-m-d');
		$file = "./Public/paylog/".$date;
		if(!is_dir($file)){
			mkdir($file);
		}
		$file = $file."/".$filename.".txt";
		$content = "【收到信息".date("Y-m-d H:i:s",time())."】".$content."\r\n\r\n";
		$open=fopen($file,"a" );
		fwrite($open,$content);
		fclose($open);
	}
	
}